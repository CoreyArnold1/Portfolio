# AnimalShelter.py

from pymongo import MongoClient

class AnimalShelter:
    """CRUD for the AAC.animals collection"""

    def __init__(self):
        uri = "mongodb://aacuser:Bocephus@nv-desktop-services.apporto.com:31580"
        self.client = MongoClient(uri)
        self.db = self.client['AAC']
        self.collection = self.db['animals']

    def create(self, data):
        if not data:
            raise ValueError("Nothing to save, data is empty")
        result = self.collection.insert_one(data)
        return bool(result.inserted_id)

    def read(self, query):
        cursor = self.collection.find(query)
        return list(cursor)
