package com.example.myfirstandroidapplication

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.BaseColumns
import android.telephony.SmsManager
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private var nameText: EditText? = null
    private var textGreeting: TextView? = null
    private var buttonSayHello: Button? = null
    private var usernameEditText: EditText? = null
    private var passwordEditText: EditText? = null
    private var buttonLogin: Button? = null

    // Database helper
    private var dbHelper: UserDatabaseHelper? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nameText = findViewById(R.id.nameText)
        textGreeting = findViewById(R.id.textGreeting)
        buttonSayHello = findViewById(R.id.buttonSayHello)
        usernameEditText = findViewById(R.id.usernameEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        buttonLogin = findViewById(R.id.buttonLogin)

        dbHelper = UserDatabaseHelper(this)

        // Enable the 'Say Hello' button only when there is text in the EditText
        nameText?.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                buttonSayHello?.isEnabled = !s.isNullOrEmpty()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        // Login Button OnClickListener
        buttonLogin?.setOnClickListener {
            val username = usernameEditText?.text.toString()
            val password = passwordEditText?.text.toString()
            if (username.isNotEmpty() && password.isNotEmpty()) {
                val user = dbHelper?.getUser(username, password)
                if (user != null) {
                    Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
                    sendSmsNotification("Welcome back, $username!")
                } else {
                    Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // SMS Notification Function
    private fun sendSmsNotification(message: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), 1)
        } else {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage("1234567890", null, message, null, null) // Replace with a valid phone number
        }
    }

    // SayHello Function
    fun sayHello(view: View?) {
        val name = nameText?.text.toString()
        textGreeting?.text = if (name.isNotEmpty()) {
            "Hello $name"
        } else {
            "You must enter a name"
        }
    }
}

// SQLite Database Helper
class UserDatabaseHelper(context: android.content.Context) : android.database.sqlite.SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: android.database.sqlite.SQLiteDatabase) {
        val CREATE_TABLE_QUERY = "CREATE TABLE $TABLE_NAME (" +
                "${BaseColumns._ID} INTEGER PRIMARY KEY," +
                "$COLUMN_USERNAME TEXT," +
                "$COLUMN_PASSWORD TEXT)"
        db.execSQL(CREATE_TABLE_QUERY)
    }

    override fun onUpgrade(db: android.database.sqlite.SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    // Insert User into Database
    fun addUser(username: String, password: String) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username)
            put(COLUMN_PASSWORD, password)
        }
        db.insert(TABLE_NAME, null, values)
    }

    // Get User by Username and Password
    fun getUser(username: String, password: String): User? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME,
            arrayOf(BaseColumns._ID, COLUMN_USERNAME, COLUMN_PASSWORD),
            "$COLUMN_USERNAME=? AND $COLUMN_PASSWORD=?",
            arrayOf(username, password),
            null, null, null
        )

        var user: User? = null
        if (cursor != null && cursor.moveToFirst()) {
            val id = cursor.getLong(cursor.getColumnIndex(BaseColumns._ID))
            val usernameFromDb = cursor.getString(cursor.getColumnIndex(COLUMN_USERNAME))
            val passwordFromDb = cursor.getString(cursor.getColumnIndex(COLUMN_PASSWORD))
            user = User(id, usernameFromDb, passwordFromDb)
        }
        cursor.close()
        return user
    }

    companion object {
        const val DATABASE_NAME = "user.db"
        const val DATABASE_VERSION = 1
        const val TABLE_NAME = "users"
        const val COLUMN_USERNAME = "username"
        const val COLUMN_PASSWORD = "password"
    }
}

// User data model
data class User(val id: Long, val username: String, val password: String)
